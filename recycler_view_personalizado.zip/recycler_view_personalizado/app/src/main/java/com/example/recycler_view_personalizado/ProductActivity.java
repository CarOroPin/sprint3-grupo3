package com.example.recycler_view_personalizado;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;



public class ProductActivity extends AppCompatActivity {

    ArrayList<Personaje> arrayList_personajes;
    RecyclerView recyclerView_personajes;
    AdaptadorPersonal adaptadorPersonaje;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);

        arrayList_personajes = new ArrayList<>();


        recyclerView_personajes = findViewById(R.id.id_ap_recyclerview_productos);
        recyclerView_personajes.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        recyclerView_personajes.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        llenarPersonajes();
        adaptadorPersonaje = new AdaptadorPersonal(arrayList_personajes);
        recyclerView_personajes.setAdapter(adaptadorPersonaje);
    }

   private void llenarPersonajes() {
        arrayList_personajes.add(new Personaje("krusty", "informacion krusty", R.drawable.krusti));
        arrayList_personajes.add(new Personaje("Bart", "informacion Bart", R.drawable.bart));
        arrayList_personajes.add(new Personaje("Burns", "informacion Burns", R.drawable.burns));
        arrayList_personajes.add(new Personaje("Flanders", "informacion Flanders", R.drawable.flanders));
        arrayList_personajes.add(new Personaje("Homero", "informacion Homero", R.drawable.homero));
        arrayList_personajes.add(new Personaje("Lisa", "informacion Lisa", R.drawable.lisa));
        arrayList_personajes.add(new Personaje("Magie", "informacion Magie", R.drawable.magie));
        arrayList_personajes.add(new Personaje("Marge", "informacion Marge", R.drawable.marge));
        arrayList_personajes.add(new Personaje("Milhouse", "informacion Milhouse", R.drawable.milhouse));


   }

}
