package com.example.recycler_view_personalizado;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
/*import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;*/

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

//import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
     /*ArrayList<Personaje> arrayList_personajes;
     RecyclerView recyclerView_personajes;
     AdaptadorPersonal adaptadorPersonaje;*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       /* arrayList_personajes = new ArrayList<>();

        recyclerView_personajes = findViewById(R.id.id_ap_recyclerview_productos);
        recyclerView_personajes.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        recyclerView_personajes.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        llenarPersonajes();
        adaptadorPersonaje = new AdaptadorPersonal(arrayList_personajes);
        recyclerView_personajes.setAdapter(adaptadorPersonaje);*/
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_activity, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.id_ma_item_productos:
                Toast.makeText(this, "Productos", Toast.LENGTH_LONG);
                Intent intent_productos= new Intent(this, ProductActivity.class);
                startActivity(intent_productos);
                break;
            case R.id.id_ma_item_servicios:
                Toast.makeText(this, "Servicios", Toast.LENGTH_LONG);
                Intent intent_servicios= new Intent(this, ServiceActivity.class);
                startActivity(intent_servicios);
                break;
            case R.id.id_ma_item_sucursales:
                Toast.makeText(this, "Sucursales", Toast.LENGTH_LONG);
                Intent intent_sucursales= new Intent(this, SucursalActivity.class);
                startActivity(intent_sucursales);
                break;

        }
        return super.onOptionsItemSelected(item);
    }

    /*private void llenarPersonajes(){
        arrayList_personajes.add(new Personaje("krusty", "informacion krusty", R.drawable.krusti));
        arrayList_personajes.add(new Personaje("Bart", "informacion Bart", R.drawable.bart));
        arrayList_personajes.add(new Personaje("Burns", "informacion Burns", R.drawable.burns));
        arrayList_personajes.add(new Personaje("Flanders", "informacion Flanders", R.drawable.flanders));
        arrayList_personajes.add(new Personaje("Homero", "informacion Homero", R.drawable.homero));
        arrayList_personajes.add(new Personaje("Lisa", "informacion Lisa", R.drawable.lisa));
        arrayList_personajes.add(new Personaje("Magie", "informacion Magie", R.drawable.magie));
        arrayList_personajes.add(new Personaje("Marge", "informacion Marge", R.drawable.marge));
        arrayList_personajes.add(new Personaje("Milhouse", "informacion Milhouse", R.drawable.milhouse));



    }*/
}